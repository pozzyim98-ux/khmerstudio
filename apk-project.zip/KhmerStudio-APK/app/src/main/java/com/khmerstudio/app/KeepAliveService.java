package com.khmerstudio.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.IBinder;
import android.os.PowerManager;

/** Keeps the process (and the dubbing server) alive while the user switches to other apps. */
public class KeepAliveService extends Service {
    PowerManager.WakeLock lock;

    @Override public int onStartCommand(Intent i, int flags, int id) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("ks", "Khmer Studio", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, "ks")
                .setContentTitle("Khmer Studio")
                .setContentText("កំពុងដំណើរការ…")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true).build();
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        if (lock == null) {
            lock = getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ks:run");
            lock.acquire(6 * 60 * 60 * 1000L);
        }
        return START_STICKY;
    }

    @Override public void onDestroy() { if (lock != null && lock.isHeld()) lock.release(); super.onDestroy(); }
    @Override public IBinder onBind(Intent i) { return null; }
}
