package com.khmerstudio.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

/** Khmer Studio as one app: ffmpeg + whisper.cpp (native), Python server (Chaquopy), WebView UI. */
public class MainActivity extends Activity {
    static final String BASE = "http://127.0.0.1:8765";
    static final String MODEL_NAME = "ggml-small.bin";
    static final String MODEL_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/" + MODEL_NAME;
    static final long MODEL_MIN = 480_000_000L;

    WebView web;
    ValueCallback<Uri[]> chooser;
    LinearLayout box;
    TextView status;
    ProgressBar bar;
    Button retry;
    volatile boolean booting = false;
    volatile String pyError = null;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        FrameLayout root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(0xFF070A1A);
        box.setPadding(48, 48, 48, 48);
        status = new TextView(this);
        status.setTextColor(0xFFE8ECFF);
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(true);
        retry = new Button(this);
        retry.setText("ព្យាយាមម្តងទៀត");
        retry.setVisibility(View.GONE);
        retry.setOnClickListener(v -> boot());
        box.addView(status, new LinearLayout.LayoutParams(-1, -2));
        box.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        box.addView(retry, new LinearLayout.LayoutParams(-2, -2));
        root.addView(box, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "KSApp");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                try { startActivityForResult(p.createIntent(), 7); }
                catch (Exception e) { chooser = null; return false; }
                return true;
            }
        });

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        try { startForegroundService(new Intent(this, KeepAliveService.class)); } catch (Exception ignored) {}
        boot();
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == 7 && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            chooser = null;
        }
    }

    @Override public void onBackPressed() { moveTaskToBack(true); }

    // ------------------------------------------------------------------ start-up
    void say(String t) { runOnUiThread(() -> status.setText(t)); }

    void boot() {
        if (booting) return;
        booting = true;
        runOnUiThread(() -> { box.setVisibility(View.VISIBLE); retry.setVisibility(View.GONE); bar.setIndeterminate(true); });
        new Thread(() -> {
            try {
                say("កំពុងរៀបចំកម្មវិធី…");
                File base = getExternalFilesDir(null);
                if (base == null) base = getFilesDir();
                File app = new File(getFilesDir(), "app"); app.mkdirs();
                copyAsset("index.html", new File(app, "index.html"), false);
                copyAsset("license_pub.txt", new File(app, "license_pub.txt"), true);

                String nl = getApplicationInfo().nativeLibraryDir;
                File ff = new File(nl, "libffmpeg.so");
                if (!ff.exists()) throw new Exception("libffmpeg.so មិនមាន. native libs = " + Arrays.toString(new File(nl).list()));
                run(new String[]{ff.getPath(), "-version"}, true);       // throws if Android refuses to execute it
                File wh = pickWhisper(nl);
                File model = ensureModel(base);

                say("កំពុងចាប់ផ្តើម server…");
                if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
                final Python py = Python.getInstance();
                final String dataDir = new File(base, "data").getPath();
                final int threads = Math.max(2, Math.min(6, Runtime.getRuntime().availableProcessors() - 2));
                final File fWh = wh, fModel = model, fApp = app, fFf = ff;
                pyError = null;
                Thread t = new Thread(() -> {
                    try {
                        py.getModule("main_android").callAttr("start", fApp.getPath(), dataDir, fFf.getPath(),
                                fWh.getPath(), fModel.getPath(), "/system/fonts", threads);
                    } catch (Throwable e) { pyError = e.toString(); }
                }, "ks-server");
                t.start();
                for (int i = 0; i < 90; i++) {
                    if (up()) { runOnUiThread(() -> { box.setVisibility(View.GONE); web.loadUrl(BASE); }); return; }
                    if (!t.isAlive()) break;
                    Thread.sleep(1000);
                }
                throw new Exception("Server មិនចាប់ផ្តើម. " + (pyError == null ? "" : pyError));
            } catch (Throwable e) {
                String m = e.toString();
                runOnUiThread(() -> {
                    status.setText("មានបញ្ហា (ថតអេក្រង់ផ្ញើមកអ្នកអភិវឌ្ឍន៍)\n\n" + m);
                    bar.setIndeterminate(false); bar.setProgress(0); retry.setVisibility(View.VISIBLE);
                });
            } finally { booting = false; }
        }, "ks-boot").start();
    }

    void copyAsset(String name, File dst, boolean optional) throws IOException {
        try (InputStream in = getAssets().open(name); OutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[1 << 16]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } catch (IOException e) {
            if (!optional) throw e;
            dst.delete();
        }
    }

    /** Runs a command; returns exit code. If mustRun, any failure to execute is an error. */
    int run(String[] cmd, boolean mustRun) throws Exception {
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        StringBuilder sb = new StringBuilder(); String l;
        while ((l = r.readLine()) != null && sb.length() < 2000) sb.append(l).append('\n');
        if (!p.waitFor(20, TimeUnit.SECONDS)) { p.destroyForcibly(); throw new Exception("timeout: " + cmd[0]); }
        int code = p.exitValue();
        if (mustRun && code != 0) throw new Exception(new File(cmd[0]).getName() + " exit " + code + ": " + sb);
        return code;
    }

    File pickWhisper(String nl) throws Exception {
        boolean dot = false;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new java.io.FileInputStream("/proc/cpuinfo")))) {
            String l; while ((l = r.readLine()) != null) if (l.contains("asimddp")) { dot = true; break; }
        } catch (Exception ignored) {}
        File fast = new File(nl, "libwhisper_dp.so"), plain = new File(nl, "libwhisper.so");
        if (dot && fast.exists()) {
            try { if (run(new String[]{fast.getPath(), "-h"}, false) < 128) return fast; } catch (Exception ignored) {}
        }
        if (!plain.exists()) throw new Exception("libwhisper.so មិនមាន");
        int c = run(new String[]{plain.getPath(), "-h"}, false);
        if (c >= 128) throw new Exception("whisper មិនអាចដំណើរការលើទូរស័ព្ទនេះ (exit " + c + ")");
        return plain;
    }

    File ensureModel(File base) throws Exception {
        File dir = new File(base, "models"); dir.mkdirs();
        File f = new File(dir, MODEL_NAME);
        if (f.length() >= MODEL_MIN) return f;
        File part = new File(dir, MODEL_NAME + ".part");
        long have = part.exists() ? part.length() : 0;
        HttpURLConnection c = (HttpURLConnection) new URL(MODEL_URL).openConnection();
        c.setConnectTimeout(20000); c.setReadTimeout(30000);
        if (have > 0) c.setRequestProperty("Range", "bytes=" + have + "-");
        int code = c.getResponseCode();
        if (code == 200) have = 0;
        else if (code != 206) throw new Exception("ទាញ model មិនបាន: HTTP " + code + " (ពិនិត្យអ៊ីនធឺណិត)");
        final long total = have + c.getContentLengthLong();
        long done = have, lastUi = 0;
        try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(part, have > 0)) {
            byte[] buf = new byte[1 << 17]; int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n); done += n;
                long now = System.currentTimeMillis();
                if (now - lastUi > 400) {
                    lastUi = now; final long d = done;
                    runOnUiThread(() -> {
                        bar.setIndeterminate(false); bar.setMax(1000); bar.setProgress((int) (d * 1000 / Math.max(1, total)));
                        status.setText("កំពុងទាញ Whisper model (ម្តងគត់)\n" + (d >> 20) + " / " + (total >> 20) + " MB\nសូមកុំបិទកម្មវិធី");
                    });
                }
            }
        }
        if (part.length() < MODEL_MIN) throw new Exception("ទាញ model មិនពេញ (" + part.length() + " bytes) សូមព្យាយាមម្តងទៀត");
        if (!part.renameTo(f)) throw new Exception("មិនអាចរក្សាទុក model");
        return f;
    }

    boolean up() {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(BASE + "/api/status").openConnection();
            c.setConnectTimeout(800); c.setReadTimeout(1500);
            boolean ok = c.getResponseCode() == 200; c.disconnect(); return ok;
        } catch (Exception e) { return false; }
    }

    // ------------------------------------------------------------------ page -> phone (downloads)
    class Bridge {
        @JavascriptInterface public void saveBase64(String name, String mime, String b64) {
            try { save(name, mime, new ByteArrayInputStream(Base64.decode(b64, Base64.DEFAULT))); }
            catch (Exception e) { toast("Save failed: " + e.getMessage()); }
        }
        @JavascriptInterface public void saveUrl(String url, String name) {
            new Thread(() -> {
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    String n = (name == null || name.isEmpty()) ? url.substring(url.lastIndexOf('/') + 1) : name;
                    String m = c.getContentType();
                    try (InputStream in = c.getInputStream()) { save(n, m == null ? "application/octet-stream" : m, in); }
                } catch (Exception e) { toast("Save failed: " + e.getMessage()); }
            }).start();
        }
    }

    void save(String name, String mime, InputStream in) throws Exception {
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, name);
        v.put(MediaStore.Downloads.MIME_TYPE, mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
        v.put(MediaStore.Downloads.RELATIVE_PATH, "Download/KhmerStudio");
        v.put(MediaStore.Downloads.IS_PENDING, 1);
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        try (OutputStream out = getContentResolver().openOutputStream(u)) {
            byte[] buf = new byte[1 << 16]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        ContentValues d = new ContentValues();
        d.put(MediaStore.Downloads.IS_PENDING, 0);
        getContentResolver().update(u, d, null, null);
        toast("✔ Saved: Download/KhmerStudio/" + name);
    }

    void toast(String t) { runOnUiThread(() -> Toast.makeText(this, t, Toast.LENGTH_LONG).show()); }
}
