"""Entry point called from MainActivity: runs the Khmer Studio server inside the app (Chaquopy)."""
import os


def start(app_dir, data_dir, ffmpeg, whisper, model, fonts, threads):
    os.environ.update(
        KS_APP_DIR=app_dir, KS_DATA=data_dir, KS_FFMPEG=ffmpeg, KS_WHISPER_CLI=whisper,
        WHISPER_CPP_MODEL=model, KS_FONTS=fonts, KS_NO_OPEN="1", GPU="0", HOME=data_dir,
        WHISPER_THREADS=str(int(threads)), KS_ANDROID="1")
    import server
    server.main()
