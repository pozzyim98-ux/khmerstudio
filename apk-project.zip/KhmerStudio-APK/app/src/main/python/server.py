#!/usr/bin/env python3
"""
Khmer Studio local server — runs ONLY on your computer (127.0.0.1).
No API key, no token, no cloud. Uses your own ffmpeg / Whisper / Argos Translate.

    python server.py            ->  open http://127.0.0.1:8765
"""
import hashlib, json, os, re, shutil, subprocess, sys, threading, uuid, importlib.util, webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

HERE = os.environ.get("KS_APP_DIR") or os.path.dirname(os.path.abspath(__file__))   # Android app: assets are copied to a real folder
# Installed in Program Files / AppData\Programs -> keep uploads, outputs and caches in a writable per-user folder.
WORK = os.environ.get("KS_DATA") or os.path.join(HERE, "work")
UP, OUT = os.path.join(WORK, "uploads"), os.path.join(WORK, "out")
TTS = os.path.join(WORK, "tts")            # every spoken line is kept here: same text + voice = instant next time
for d in (UP, OUT, TTS):
    os.makedirs(d, exist_ok=True)

PORT = int(os.environ.get("PORT", "8765"))
HOST = os.environ.get("HOST", "127.0.0.1")
FFMPEG = os.environ.get("KS_FFMPEG") or shutil.which("ffmpeg")
FFPROBE = os.environ.get("KS_FFPROBE") or shutil.which("ffprobe")   # optional: without it ffmpeg -i is parsed instead
WHISPER_MODEL = os.environ.get("WHISPER_MODEL", "small")   # tiny/base/small/medium/large-v3 or a local folder
IS_TERMUX = "com.termux" in os.environ.get("PREFIX", "") or bool(os.environ.get("TERMUX_VERSION"))
_HOME = os.path.expanduser("~")
WHISPER_CLI = (os.environ.get("KS_WHISPER_CLI") or shutil.which("whisper-cli") or shutil.which("main")
               or next((c for c in (os.path.join(_HOME, "whisper.cpp/build/bin/whisper-cli"),) if os.path.isfile(c)), None))  # whisper.cpp
WHISPER_CPP_MODEL = os.environ.get("WHISPER_CPP_MODEL") or next(
    (c for c in (os.path.join(_HOME, f"whisper.cpp/models/ggml-{WHISPER_MODEL}.bin"),
                 os.path.join(_HOME, "whisper.cpp/models/ggml-small.bin")) if os.path.isfile(c)), None)
if IS_TERMUX: os.environ.setdefault("GPU", "0")      # phone: no NVENC/QSV, plain libx264 is the safe choice
HAS_FW = importlib.util.find_spec("faster_whisper") is not None
HAS_ARGOS = importlib.util.find_spec("argostranslate") is not None
HAS_NLLB = all(importlib.util.find_spec(m) for m in ("transformers", "torch", "sentencepiece"))
NLLB_MODEL = os.environ.get("NLLB_MODEL", "facebook/nllb-200-distilled-600M")
NLLB_CODES = {"km": "khm_Khmr", "en": "eng_Latn", "zh": "zho_Hans", "ja": "jpn_Jpan", "ko": "kor_Hang",
              "th": "tha_Thai", "vi": "vie_Latn", "fr": "fra_Latn", "es": "spa_Latn", "de": "deu_Latn",
              "ru": "rus_Cyrl", "id": "ind_Latn", "ms": "zsm_Latn", "hi": "hin_Deva", "ar": "arb_Arab"}
_nllb = None

JOBS, FILES, LOCK = {}, {}, threading.Lock()
sys.path.insert(0, HERE)
from ks_license import License
LIC = License(HERE, WORK)                  # licence is only enforced when license_pub.txt exists (see keygen.py init)
_model = None


def folder_mb(p):
    t = 0
    for r, _, fs in os.walk(p):
        for f in fs:
            try: t += os.path.getsize(os.path.join(r, f))
            except OSError: pass
    return round(t / 1048576, 1)


def whisper_kind():
    if HAS_FW: return "faster-whisper"
    if WHISPER_CLI and WHISPER_CPP_MODEL: return "whisper.cpp"
    return None


# ---------------------------------------------------------------- jobs
def new_job(fn, *a):
    jid = uuid.uuid4().hex[:10]
    JOBS[jid] = {"status": "running", "progress": 0.05, "msg": "Starting…"}
    def run():
        try:
            res = fn(jid, *a) or {}
            JOBS[jid].update(res, status="done", progress=1)
        except Exception as e:
            JOBS[jid].update(status="error", error=str(e)[:500])
    threading.Thread(target=run, daemon=True).start()
    return jid


def ff(args, jid=None, total=None):
    if not FFMPEG: raise RuntimeError("ffmpeg not found — install it and add to PATH")
    cmd = [FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-progress", "pipe:1", "-nostats"] + args
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    for line in p.stdout:
        m = re.match(r"out_time_ms=(\d+)", line)
        if m and total and jid:
            JOBS[jid]["progress"] = min(0.98, int(m.group(1)) / 1e6 / total)
    err = p.stderr.read(); p.wait()
    if p.returncode: raise RuntimeError(err.strip()[-400:] or "ffmpeg failed")


def _ffinfo(path):
    """stderr of `ffmpeg -i file` (used when there is no ffprobe, e.g. inside the Android app)."""
    if not FFMPEG: return ""
    r = subprocess.run([FFMPEG, "-hide_banner", "-i", path], capture_output=True, text=True, errors="ignore")
    return r.stderr or ""


def duration(path):
    pr = FFPROBE
    if not pr:
        m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", _ffinfo(path))
        return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3)) if m else None
    try:
        return float(subprocess.check_output([pr, "-v", "error", "-show_entries", "format=duration",
                                              "-of", "default=nw=1:nk=1", path], text=True).strip())
    except Exception:
        return None


def outfile(ext):
    n = uuid.uuid4().hex[:8] + ext
    return os.path.join(OUT, n), "/api/result/" + n


_VENC = None


def venc():
    """Fastest H.264 encoder that really works on this PC: GPU (NVENC / QuickSync / AMF / VideoToolbox) else libx264 'superfast'.
    Set GPU=0 to force CPU, X264_PRESET=veryfast (or slower) for smaller files."""
    global _VENC
    if _VENC: return _VENC
    _VENC = ["-c:v", "libx264", "-preset", os.environ.get("X264_PRESET", "superfast"), "-crf", "22", "-pix_fmt", "yuv420p"]
    if FFMPEG and os.environ.get("GPU", "1") != "0":
        for args in (["-c:v", "h264_nvenc", "-preset", "p1", "-cq", "24", "-pix_fmt", "yuv420p"],
                     ["-c:v", "h264_qsv", "-global_quality", "24"],
                     ["-c:v", "h264_videotoolbox", "-q:v", "60", "-pix_fmt", "yuv420p"],
                     ["-c:v", "h264_amf", "-quality", "speed", "-pix_fmt", "yuv420p"]):
            try:   # a 1-second test encode: the encoder may be listed by ffmpeg but have no GPU behind it
                r = subprocess.run([FFMPEG, "-v", "error", "-f", "lavfi", "-i", "color=c=black:s=640x360:d=0.5"] + args + ["-f", "null", "-"],
                                   capture_output=True, timeout=20)
                if r.returncode == 0: _VENC = args; break
            except Exception:
                pass
    return _VENC


def video_size(path):
    pr = FFPROBE
    if not pr:
        m = re.search(r"Video:.*?[\s,\[](\d{2,5})x(\d{2,5})[\s,\[]", _ffinfo(path), re.S)
        if not m: raise RuntimeError("cannot read the video size")
        return int(m.group(1)), int(m.group(2))
    o = subprocess.check_output([pr, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height",
                                 "-of", "csv=p=0:s=x", path], text=True).strip().split("\n")[0]
    w, h = o.split("x")[:2]
    return int(w), int(h)


# ---------------------------------------------------------------- tasks
def t_transcribe(jid, fid, lang, engine="whisper"):
    path = FILES[fid]
    JOBS[jid]["msg"] = "Reading audio from your video…"
    kind = whisper_kind()
    lang = None if lang in ("", "auto", None) else lang
    if engine == "sensevoice": return {"segments": t_sensevoice(jid, path, lang)}
    segs = []
    if kind == "faster-whisper":
        global _model
        from faster_whisper import WhisperModel
        if _model is None:
            _model = WhisperModel(WHISPER_MODEL, device="auto", compute_type="auto")
        it, info = _model.transcribe(path, language=lang, vad_filter=os.environ.get("WHISPER_VAD", "1") != "0", word_timestamps=True)
        dur = info.duration or 1
        JOBS[jid]["msg"] = "Detecting speech rhythm and pauses…"
        for s in it:
            ws = [w for w in (s.words or []) if w.end > w.start]
            a, b = (ws[0].start, ws[-1].end) if ws else (s.start, s.end)   # real first/last spoken word = mouth open/close
            segs.append({"start": a, "end": b, "text": s.text.strip()})
            JOBS[jid]["progress"] = min(.97, s.end / dur)
            JOBS[jid]["msg"] = f"Recognised speech up to {s.end:.0f}s of {dur:.0f}s"
    elif kind == "whisper.cpp":
        wav = os.path.join(WORK, jid + ".wav")
        ff(["-i", path, "-ar", "16000", "-ac", "1", wav])
        base = os.path.join(WORK, jid)
        cmd = [WHISPER_CLI, "-m", WHISPER_CPP_MODEL, "-f", wav, "-osrt", "-of", base, "-pp",
               "-t", str(os.environ.get("WHISPER_THREADS") or max(2, min(8, (os.cpu_count() or 4) - 1)))]
        if lang: cmd += ["-l", lang]
        JOBS[jid]["msg"] = "Recognising speech (Whisper on your phone)…"
        pr = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True, errors="ignore")
        tail = []
        for line in pr.stderr:
            m = re.search(r"progress\s*=\s*(\d+)%", line)
            if m: JOBS[jid]["progress"] = min(.97, int(m.group(1)) / 100); JOBS[jid]["msg"] = f"Recognised {m.group(1)}%"
            else: tail = (tail + [line.strip()])[-6:]
        pr.wait()
        try: os.remove(wav)
        except OSError: pass
        if pr.returncode: raise RuntimeError("whisper-cli failed: " + " | ".join(tail)[-300:])
        txt = open(base + ".srt", encoding="utf-8").read()
        for blk in re.split(r"\n\s*\n", txt.replace("\r", "")):
            ln = [l for l in blk.split("\n") if l.strip()]
            i = next((k for k, l in enumerate(ln) if "-->" in l), None)
            if i is None: continue
            a, b = [x.strip().replace(",", ".") for x in ln[i].split("-->")]
            f = lambda t: sum(float(x) * m for x, m in zip(reversed(t.split(":")), (1, 60, 3600)))
            segs.append({"start": f(a), "end": f(b), "text": " ".join(ln[i + 1:])})
    else:
        raise RuntimeError("No local Whisper found (pip install faster-whisper)")
    return {"segments": segs}


_sv = {}


def t_sensevoice(jid, path, lang):
    """SenseVoice (offline): FSMN-VAD finds exactly when speech is heard, SenseVoice writes the text of each burst."""
    import numpy as np, wave
    try:
        from funasr import AutoModel
        from funasr.utils.postprocess_utils import rich_transcription_postprocess
    except ImportError:
        raise RuntimeError("SenseVoice is not installed:  pip install funasr modelscope torch torchaudio")
    JOBS[jid]["msg"] = "Reading audio from your video…"
    wav = os.path.join(WORK, jid + "_sv.wav")
    ff(["-i", path, "-vn", "-ar", "16000", "-ac", "1", wav])
    with wave.open(wav, "rb") as f: x = np.frombuffer(f.readframes(f.getnframes()), dtype=np.int16)
    if "vad" not in _sv:
        JOBS[jid]["msg"] = "Loading the voice-activity model (first run downloads it)…"
        _sv["vad"] = AutoModel(model="fsmn-vad", disable_update=True)
    if "asr" not in _sv:
        JOBS[jid]["msg"] = "Loading SenseVoice (first run downloads it)…"
        try:
            import torch; dev = "cuda:0" if torch.cuda.is_available() else "cpu"
        except Exception:
            dev = "cpu"
        _sv["asr"] = AutoModel(model="iic/SenseVoiceSmall", trust_remote_code=True, device=dev, disable_update=True)
    JOBS[jid]["msg"] = "Detecting speech rhythm and pauses…"
    spans = [(a / 1000, b / 1000) for a, b in _sv["vad"].generate(input=wav)[0]["value"]]
    vad_n = len(spans)
    if not spans:                                       # VAD heard nothing (music / quiet voice): let SenseVoice scan the whole audio
        JOBS[jid]["msg"] = "VAD found no speech -> scanning the whole audio…"
        spans = [(0.0, len(x) / 16000)]
    n = len(x) // 160
    e = np.sqrt((x[:n * 160].astype(np.float32).reshape(n, 160) ** 2).mean(1)) if n else np.zeros(1)

    def split(a, b):                                    # long bursts are cut at the quietest moment near the middle
        if b - a <= 9.0: return [(a, b)]
        lo, hi = int((a + (b - a) * .35) * 100), min(int((a + (b - a) * .65) * 100), len(e))
        m = (lo + int(np.argmin(e[lo:hi]))) / 100 if hi > lo else (a + b) / 2
        return split(a, m) + split(m, b)
    parts = [p for a, b in spans for p in split(a, b)]
    sl = lang if lang in ("zh", "en", "yue", "ja", "ko") else "auto"
    segs, empty, raw = [], 0, []
    JOBS[jid]["msg"] = f"SenseVoice: {vad_n} VAD bursts, {len(parts)} parts, language={sl}"
    for i, (a, b) in enumerate(parts):
        if b - a < 0.25: continue
        tmp = os.path.join(WORK, f"{jid}_s{i}.wav")
        with wave.open(tmp, "wb") as f:
            f.setnchannels(1); f.setsampwidth(2); f.setframerate(16000); f.writeframes(x[int(a * 16000):int(b * 16000)].tobytes())
        try:
            o = _sv["asr"].generate(input=tmp, cache={}, language=sl, use_itn=True, batch_size_s=60)
            t = rich_transcription_postprocess(o[0]["text"]).strip() if o else ""
            if not t:
                empty += 1
                if len(raw) < 3: raw.append(str(o[0]["text"])[:60] if o else "<no output>")
        finally:
            os.remove(tmp)
        if t:
            segs.append({"start": round(a, 3), "end": round(b, 3), "text": t})
            JOBS[jid]["msg"] = f"Recognised {len(segs)} lines · {b:.0f}s of {len(x) / 16000:.0f}s"
        JOBS[jid]["progress"] = min(.97, (i + 1) / len(parts))
    if not segs:
        raise RuntimeError(f"SenseVoice heard nothing: VAD bursts={vad_n}, parts={len(parts)}, empty results={empty}, language={sl}, raw={raw}. "
                           "SenseVoice only knows zh/en/yue/ja/ko - type the real language code (not auto) and check the voice is audible.")
    return segs


def t_translate_free(jid, texts, src, dst):
    """No API key: Google Translate's public web endpoint (batched & paced to avoid 429 rate-limits)."""
    import urllib.request, urllib.parse, time
    fix = {"zh": "zh-CN", "": "auto"}
    sl, tl = fix.get(src or "", src or "auto"), fix.get(dst, dst)

    def translate_single(t):
        if not t.strip(): return t
        url = "https://translate.googleapis.com/translate_a/single?" + urllib.parse.urlencode({"client": "gtx", "sl": sl, "tl": tl, "dt": "t", "q": t})
        for a in range(3):
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                d = json.loads(urllib.request.urlopen(req, timeout=12).read().decode("utf-8"))
                r = "".join(x[0] for x in d[0] if x and x[0]).strip()
                if r: return r
            except Exception:
                time.sleep(1.5 + a)
        return None

    out, ok = list(texts), 0
    idx = [i for i, t in enumerate(texts) if t.strip()]
    JOBS[jid]["msg"] = "Translating with the free translator…"
    
    # Group lines into batches (~1200 chars max) separated by newline for speed and fewer requests
    batches, cur_b, cur_len = [], [], 0
    for i in idx:
        clean_t = texts[i].replace("\n", " ").strip()
        if cur_b and cur_len + len(clean_t) > 1200:
            batches.append(cur_b)
            cur_b, cur_len = [], 0
        cur_b.append((i, clean_t))
        cur_len += len(clean_t) + 2
    if cur_b:
        batches.append(cur_b)

    done = 0
    for b in batches:
        joined = "\n".join(x[1] for x in b)
        res = translate_single(joined)
        lines = res.split("\n") if res else []
        if len(lines) == len(b):
            for (i, _), tr_line in zip(b, lines):
                if tr_line.strip():
                    out[i] = tr_line.strip()
                    ok += 1
        else:
            # Fallback to line-by-line for this batch if newline count changed
            for i, orig_t in b:
                r = translate_single(orig_t)
                if r:
                    out[i] = r
                    ok += 1
                time.sleep(0.25)
        done += len(b)
        JOBS[jid]["progress"] = done / max(1, len(idx))
        JOBS[jid]["msg"] = f"Translated {ok}/{len(idx)} lines"
        time.sleep(0.35)

    if ok == 0 and idx:
        raise RuntimeError("Free translator did not answer (check internet, or try again later)")
    return {"texts": out}


def t_translate(jid, texts, src, dst):
    if HAS_NLLB:
        return t_translate_nllb(jid, texts, src, dst)
    import argostranslate.translate as T
    langs = {l.code: l for l in T.get_installed_languages()}
    if src not in langs or dst not in langs:
        raise RuntimeError(f"Language pack {src}->{dst} not installed (see README)")
    tr = langs[src].get_translation(langs[dst])
    if tr is None: raise RuntimeError(f"No installed model {src}->{dst}")
    out = []
    for i, t in enumerate(texts):
        out.append(tr.translate(t) if t.strip() else t)
        JOBS[jid]["progress"] = (i + 1) / max(1, len(texts))
    return {"texts": out}


def t_translate_nllb(jid, texts, src, dst):
    global _nllb
    import torch
    from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
    if src not in NLLB_CODES or dst not in NLLB_CODES:
        raise RuntimeError("Language code not supported: " + ", ".join(sorted(NLLB_CODES)))
    if _nllb is None:
        tok = AutoTokenizer.from_pretrained(NLLB_MODEL)
        mdl = AutoModelForSeq2SeqLM.from_pretrained(NLLB_MODEL)
        dev = "cuda" if torch.cuda.is_available() else "cpu"
        _nllb = (tok, mdl.to(dev).eval(), dev)
    tok, mdl, dev = _nllb
    tok.src_lang = NLLB_CODES[src]
    out, B = list(texts), 8
    idx = [i for i, t in enumerate(texts) if t.strip()]
    for k in range(0, len(idx), B):
        part = idx[k:k + B]
        enc = tok([texts[i] for i in part], return_tensors="pt", padding=True, truncation=True, max_length=256).to(dev)
        with torch.no_grad():
            gen = mdl.generate(**enc, forced_bos_token_id=tok.convert_tokens_to_ids(NLLB_CODES[dst]),
                               max_new_tokens=256, num_beams=4)
        for i, t in zip(part, tok.batch_decode(gen, skip_special_tokens=True)):
            out[i] = t
        JOBS[jid]["progress"] = min(.97, (k + B) / max(1, len(idx)))
    return {"texts": out}


def t_removevocal(jid, fid):
    src = FILES[fid]; p, url = outfile(".mp4")
    # classic centre-channel cancellation (vocals are usually mixed to the centre)
    ff(["-i", src, "-map", "0:v?", "-c:v", "copy", "-af", "pan=stereo|c0=c0-c1|c1=c1-c0", "-c:a", "aac", "-b:a", "192k", p],
       jid, duration(src))
    return {"url": url}


def t_cut(jid, fid, a, b):
    src = FILES[fid]; p, url = outfile(".mp4")
    ff(["-ss", str(a), "-to", str(b), "-i", src] + venc() + ["-c:a", "aac", p],
       jid, b - a)
    return {"url": url}


def t_merge(jid, ids):
    lst = os.path.join(WORK, jid + ".txt"); p, url = outfile(".mp4")
    with open(lst, "w", encoding="utf-8") as f:
        for i in ids:
            f.write("file '" + FILES[i].replace("'", "'\\''") + "'\n")
    total = sum(duration(FILES[i]) or 0 for i in ids) or None
    ff(["-f", "concat", "-safe", "0", "-i", lst] + venc() + ["-c:a", "aac", p], jid, total)
    return {"url": url}


FONTS = os.environ.get("KS_FONTS") or os.path.join(HERE, "fonts")      # optional: drop NotoSansKhmer-Regular.ttf here if the PC has no Khmer font


def subs_filter(sp, size, color, bottom):
    """ffmpeg 'subtitles' filter text for a .srt file (Khmer is shaped by libass)."""
    c = color.lstrip("#"); bgr = c[4:6] + c[2:4] + c[0:2]
    style = f"FontName=Noto Sans Khmer,FontSize={int(size*0.6)},PrimaryColour=&H{bgr}&,Outline=2,MarginV={int(bottom*6)}"
    esc = sp.replace("\\", "/").replace(":", "\\:")
    fd = ""
    if os.path.isdir(FONTS):
        fd = ":fontsdir='" + FONTS.replace("\\", "/").replace(":", "\\:") + "'"
    return f"subtitles='{esc}':force_style='{style}'{fd}"


def t_burn(jid, fid, srt, size, color, bottom):
    src = FILES[fid]; p, url = outfile(".mp4")
    sp = os.path.join(WORK, jid + ".srt")
    open(sp, "w", encoding="utf-8").write(srt)
    ff(["-i", src, "-vf", subs_filter(sp, size, color, bottom)] + venc() + ["-c:a", "copy", p],
       jid, duration(src))
    return {"url": url}


def t_removesub(jid, fid, x, y, w, h, mode="blur"):
    """Hide the OLD burned-in subtitle: blur / black bar / smooth fill over one rectangle on every frame.
    x,y,w,h are fractions (0..1) of the picture. Only ffmpeg is needed - no key, no download."""
    src = FILES[fid]; W, H = video_size(src)
    ev = lambda v: int(v) // 2 * 2
    X, Y = ev(max(0.0, min(1.0, x)) * W), ev(max(0.0, min(1.0, y)) * H)
    if mode == "delogo": X, Y = max(2, X), max(2, Y)                       # delogo must stay 1px inside the frame
    RW = max(4, min(ev(max(0.02, w) * W), ev(W - X - (2 if mode == "delogo" else 0))))
    RH = max(4, min(ev(max(0.02, h) * H), ev(H - Y - (2 if mode == "delogo" else 0))))
    if mode == "box":
        vf = f"drawbox=x={X}:y={Y}:w={RW}:h={RH}:color=black@1:t=fill"
    elif mode == "delogo":
        vf = f"delogo=x={X}:y={Y}:w={RW}:h={RH}"
    else:
        vf = f"split[a][b];[b]crop={RW}:{RH}:{X}:{Y},gblur=sigma=22:steps=2[c];[a][c]overlay={X}:{Y}"
    p, url = outfile(".mp4"); oid = uuid.uuid4().hex[:8]
    JOBS[jid]["msg"] = f"Covering the old subtitle ({RW}x{RH} at {X},{Y})…"
    ff(["-i", src, "-vf", vf, "-map", "0:v:0", "-map", "0:a?", "-sn"] + venc() +
       ["-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", p], jid, duration(src))
    FILES[oid] = p                      # the result can be used again (dub / burn-in) without uploading it back
    return {"url": url, "id": oid}


def fx_graph(jid, src, fx, logo_idx):
    """ONE ffmpeg filter graph = blur the OLD subtitle  ->  burn the NEW Khmer subtitle  ->  stamp the logo.
    fx = {"blur": {x,y,w,h,mode}, "subs": {srt,size,color,bottom}, "logo": {id,pos,scale,opacity}}  (every part optional)
    Returns (extra ffmpeg inputs, graph text, label of the final video stream) - graph is "" when nothing is requested."""
    fx = fx or {}
    ev = lambda v: int(v) // 2 * 2
    steps, cur, n, ins = [], "0:v", [0], []

    def nxt():
        n[0] += 1; return f"fx{n[0]}"

    bl = fx.get("blur")
    if bl:                                                               # same maths as the stand-alone "remove old subtitle"
        W, H = video_size(src); mode = bl.get("mode", "blur")
        X, Y = ev(max(0.0, min(1.0, float(bl["x"]))) * W), ev(max(0.0, min(1.0, float(bl["y"]))) * H)
        if mode == "delogo": X, Y = max(2, X), max(2, Y)
        RW = max(4, min(ev(max(0.02, float(bl["w"])) * W), ev(W - X - (2 if mode == "delogo" else 0))))
        RH = max(4, min(ev(max(0.02, float(bl["h"])) * H), ev(H - Y - (2 if mode == "delogo" else 0))))
        o = nxt()
        if mode == "box":
            steps.append(f"[{cur}]drawbox=x={X}:y={Y}:w={RW}:h={RH}:color=black@1:t=fill[{o}]")
        elif mode == "delogo":
            steps.append(f"[{cur}]delogo=x={X}:y={Y}:w={RW}:h={RH}[{o}]")
        else:
            steps.append(f"[{cur}]split[fa{n[0]}][fb{n[0]}];[fb{n[0]}]crop={RW}:{RH}:{X}:{Y},gblur=sigma=22:steps=2[fc{n[0]}];"
                         f"[fa{n[0]}][fc{n[0]}]overlay={X}:{Y}[{o}]")
        cur = o

    sb = fx.get("subs")
    if sb and str(sb.get("srt", "")).strip():                           # new Khmer subtitle goes ON TOP of the blur
        sp = os.path.join(WORK, jid + "_fx.srt")
        open(sp, "w", encoding="utf-8").write(sb["srt"])
        o = nxt()
        steps.append(f"[{cur}]{subs_filter(sp, float(sb.get('size', 34)), str(sb.get('color', '#ffffff')), float(sb.get('bottom', 8)))}[{o}]")
        cur = o

    lg = fx.get("logo")
    if lg and lg.get("id") in FILES:
        W, H = video_size(src)
        ins = ["-i", FILES[lg["id"]]]
        lw = max(16, ev(max(0.03, min(0.6, float(lg.get("scale", 0.15)))) * W))
        op = max(0.05, min(1.0, float(lg.get("opacity", 1.0))))
        m = max(6, int(W * 0.02))
        pos = {"tl": f"{m}:{m}", "tr": f"main_w-overlay_w-{m}:{m}",
               "bl": f"{m}:main_h-overlay_h-{m}", "br": f"main_w-overlay_w-{m}:main_h-overlay_h-{m}"}.get(lg.get("pos", "tr"))
        steps.append(f"[{logo_idx}:v]format=rgba,scale={lw}:-2,colorchannelmixer=aa={op:.2f}[lg]")
        o = nxt()
        steps.append(f"[{cur}][lg]overlay={pos}:format=auto[{o}]")
        cur = o
    return ins, ";".join(steps), cur


def t_export(jid, fid, aid, bg, fx):
    """The ONLY place that makes the final download: original video (+ Khmer dub voice) + blur + Khmer subtitle + logo."""
    src = FILES[fid]; total = duration(src)
    p, url = outfile(".mp4")
    dub = FILES.get(aid) if aid else None
    inputs = ["-i", src] + (["-i", dub] if dub else [])
    ins, graph, lab = fx_graph(jid, src, fx, len(inputs) // 2)
    inputs += ins
    if not graph and not dub:
        raise RuntimeError("គ្មានអ្វីត្រូវដាក់ — សូមជ្រើស subtitle / blur / logo ឬបង្កើតសំឡេងខ្មែរជាមុន")
    fc = [graph] if graph else []
    if dub and bg > 0 and has_audio(src):
        fc.append(f"[0:a]volume={bg:.2f}[a0];[a0][1:a]amix=inputs=2:duration=longest:dropout_transition=0,volume=2[a]")
        amap = ["-map", "[a]"]
    elif dub:
        amap = ["-map", "1:a"]
    else:
        amap = ["-map", "0:a?"]
    vmap = ["-map", f"[{lab}]"] if graph else ["-map", "0:v:0"]
    JOBS[jid]["msg"] = "Rendering the final video (blur · subtitle · logo)…" if graph else "Mixing the new voice into the video…"
    cmd = inputs + (["-filter_complex", ";".join(fc)] if fc else []) + vmap + amap + (venc() if graph else ["-c:v", "copy"]) + \
        ["-c:a", "aac", "-b:a", "192k", "-sn", "-movflags", "+faststart"] + (["-t", f"{total:.3f}"] if total else []) + [p]
    ff(cmd, jid, total)
    return {"url": url}


# ---------------------------------------------------------------- voice dubbing (TTS)
SR = 24000
HAS_EDGE = importlib.util.find_spec("edge_tts") is not None
HAS_NUMPY = importlib.util.find_spec("numpy") is not None
HAS_MMS = HAS_NLLB and HAS_NUMPY
_mms = None


def has_audio(path):
    pr = FFPROBE
    if not pr: return "Audio:" in _ffinfo(path)
    try:
        return bool(subprocess.check_output([pr, "-v", "error", "-select_streams", "a", "-show_entries",
                                             "stream=index", "-of", "csv=p=0", path], text=True).strip())
    except Exception:
        return True


def synth_edge(jobid, texts, paths, voices, rates, pitches):
    import asyncio, edge_tts
    bad, last_err = [], [""]
    async def one(sem, i, text, path, voice, rate, pitch):
        async with sem:
            text = re.sub(r"[\u200b-\u200d\ufeff]", "", text).strip()
            if not re.search(r"\w", text):                    # only punctuation / symbols -> nothing to speak
                bad.append(i); return
            for a in range(3):
                try:
                    await edge_tts.Communicate(text, voice, rate=rate, pitch=pitch).save(path)
                    if os.path.isfile(path) and os.path.getsize(path) > 200: return
                    raise RuntimeError("empty audio")
                except Exception as e:
                    last_err[0] = str(e)
                    if a == 0 and pitch != "+0Hz":             # unusual pitch can be refused -> retry with the plain one
                        pitch = "+0Hz"
                    await asyncio.sleep(1 + a)
            bad.append(i)                                       # skip this line, do not kill the whole dub
    async def run():
        sem = asyncio.Semaphore(5); done = 0
        ts = [asyncio.ensure_future(one(sem, i, t, p, v, r, h)) for i, (t, p, v, r, h) in enumerate(zip(texts, paths, voices, rates, pitches))]
        for f in asyncio.as_completed(ts):
            await f; done += 1
            if jobid: JOBS[jobid]["progress"] = 0.05 + 0.6 * done / max(1, len(ts))
    asyncio.run(run())
    if len(bad) == len(texts):
        raise RuntimeError("Edge TTS gave no audio for any line (" + (last_err[0] or "no text") + "). Check internet and run:  pip install -U edge-tts")
    return bad


def synth_mms(jobid, texts, paths):
    global _mms
    import wave, numpy as np, torch
    from transformers import VitsModel, AutoTokenizer
    if _mms is None:
        _mms = (AutoTokenizer.from_pretrained("facebook/mms-tts-khm"), VitsModel.from_pretrained("facebook/mms-tts-khm").eval())
    tok, m = _mms
    for i, (t, p) in enumerate(zip(texts, paths)):
        enc = tok(t, return_tensors="pt")
        with torch.no_grad():
            w = m(**enc).waveform[0].numpy()
        pcm = (np.clip(w, -1, 1) * 32767).astype(np.int16)
        with wave.open(p, "wb") as f:
            f.setnchannels(1); f.setsampwidth(2); f.setframerate(m.config.sampling_rate); f.writeframes(pcm.tobytes())
        if jobid: JOBS[jobid]["progress"] = 0.05 + 0.6 * (i + 1) / max(1, len(texts))


def synth_test(texts, paths):
    """Beep 'voice' used only to test the pipeline without any TTS installed."""
    for t, p in zip(texts, paths):
        d = max(0.4, min(8.0, len(t) * 0.07))
        ff(["-f", "lavfi", "-i", f"sine=frequency=330:duration={d}", p])


def synth(jobid, engine, texts, paths, voice, rate, pitch=None):
    n = len(texts)
    if engine == "edge":
        if not HAS_EDGE: raise RuntimeError("edge-tts not installed: pip install edge-tts")
        L = lambda x, d: x if isinstance(x, list) else [x if x is not None else d] * n
        return synth_edge(jobid, texts, paths, L(voice, "km-KH-SreymomNeural"), L(rate, "+0%"), L(pitch, "+0Hz"))
    elif engine == "mms":
        if not HAS_MMS: raise RuntimeError("MMS needs: pip install transformers torch sentencepiece numpy")
        synth_mms(jobid, texts, paths)
    elif engine == "test":
        synth_test(texts, paths)
    else:
        raise RuntimeError("unknown engine")


def line_params(c, voice, rate):
    """(edge voice, rate %, pitch Hz) for one cue - role (girl/boy/old...) changes voice, pitch and speed."""
    v, dp, dr = ROLES.get(c.get("role", ""), (voice, 0, 0))
    return v, f"{max(-60, min(90, int(rate) + dr)):+d}%", f"{dp:+d}Hz"


def tts_path(engine, text, v, r, p):
    t = re.sub(r"\s+", " ", text).strip()
    k = hashlib.sha1(f"{engine}|{v}|{r}|{p}|{t}".encode("utf-8")).hexdigest()[:20]
    return os.path.join(TTS, k + (".mp3" if engine == "edge" else ".wav"))


def tts_make(jid, engine, items):
    """items = [(text, voice, rate, pitch)] -> list of cached audio paths (None = this line cannot be spoken).
    Only lines that are not in the cache yet are sent to the TTS engine."""
    paths, need, seen = [None] * len(items), [], {}
    for i, (t, v, r, p) in enumerate(items):
        t = re.sub(r"\s+", " ", str(t)).strip()
        fp = tts_path(engine, t, v, r, p)
        if os.path.isfile(fp) and os.path.getsize(fp) > 200: paths[i] = fp; continue
        if fp in seen: seen[fp].append(i); continue
        seen[fp] = [i]; need.append((fp, t, v, r, p))
    if need:
        tmp = os.path.join(WORK, "tts_tmp_" + uuid.uuid4().hex[:8]); os.makedirs(tmp, exist_ok=True)
        tp = [os.path.join(tmp, os.path.basename(x[0])) for x in need]
        err = None
        try:
            bad = set(synth(jid, engine, [x[1] for x in need], tp, [x[2] for x in need], [x[3] for x in need], [x[4] for x in need]) or [])
        except RuntimeError as e:
            err, bad = e, set(range(len(need)))
        for j, x in enumerate(need):
            if j in bad or not os.path.isfile(tp[j]) or os.path.getsize(tp[j]) <= 200: continue
            os.replace(tp[j], x[0])
            for i in seen[x[0]]: paths[i] = x[0]
        shutil.rmtree(tmp, ignore_errors=True)
        if err and not any(paths): raise err        # engine really broken (no line worked, nothing cached) -> tell the user why
    return paths


def t_ttsbatch(jid, cues, engine, voice, rate):
    """Speak every line (cache first) and measure how long each clip really is -> the page shows which lines are too long."""
    if not FFMPEG or not HAS_NUMPY: raise RuntimeError("needs ffmpeg + numpy (pip install numpy)")
    items = []
    for c in cues:
        v, r, p = line_params(c, voice, rate)
        items.append((str(c.get("text", "")), v, r, p))
    JOBS[jid]["msg"] = f"Speaking {len(items)} lines (cached lines are skipped)…"
    paths = tts_make(jid, engine, items)
    JOBS[jid]["msg"] = "Measuring each voice clip…"
    return {"durs": [round(len(decode(pp)) / SR, 3) if pp else None for pp in paths],
            "failed": sum(1 for pp in paths if not pp)}


def trim_sil(a, thr=250, keep=int(0.015 * SR)):
    import numpy as np
    nz = np.flatnonzero(np.abs(a.astype(np.int32)) > thr)
    return a if len(nz) == 0 else a[max(0, nz[0] - keep): nz[-1] + 1 + keep]


def decode(path, tempo=None):
    import numpy as np
    af = ["-af", f"atempo={tempo:.3f}"] if tempo and abs(tempo - 1) > 0.02 else []
    p = subprocess.run([FFMPEG, "-v", "error", "-i", path] + af + ["-ar", str(SR), "-ac", "1", "-f", "s16le", "-"],
                       capture_output=True)
    if p.returncode: raise RuntimeError(p.stderr.decode(errors="ignore")[-300:])
    return trim_sil(np.frombuffer(p.stdout, dtype=np.int16))


# role -> (edge voice, pitch Hz, rate %).  Khmer Edge TTS has only 2 voices, so age is imitated with pitch/speed.
ROLES = {
    "female": ("km-KH-SreymomNeural", 0, 0),
    "male":   ("km-KH-PisethNeural", 0, 0),
    "girl":   ("km-KH-SreymomNeural", 40, 8),
    "boy":    ("km-KH-PisethNeural", 35, 8),
    "oldw":   ("km-KH-SreymomNeural", -22, -12),
    "oldm":   ("km-KH-PisethNeural", -22, -12),
}


def f0_of(path, a, b):
    """Median pitch (Hz) of the speech between a..b seconds, or None."""
    import numpy as np
    r = subprocess.run([FFMPEG, "-v", "error", "-ss", f"{a:.3f}", "-t", f"{max(0.3, b - a):.3f}", "-i", path,
                        "-vn", "-ar", "16000", "-ac", "1", "-f", "s16le", "-"], capture_output=True)
    x = np.frombuffer(r.stdout, dtype=np.int16).astype(np.float32)
    N, H, f = 640, 320, []
    lo, hi = 16000 // 400, 16000 // 70
    for i in range(0, len(x) - N, H):
        w = x[i:i + N] * np.hanning(N)
        if np.sqrt(np.mean(w * w)) < 300: continue
        ac = np.fft.irfft(np.abs(np.fft.rfft(w, 2 * N)) ** 2)[:N]
        k = lo + int(np.argmax(ac[lo:hi]))
        if ac[k] / (ac[0] + 1e-9) > 0.35: f.append(16000.0 / k)
    return float(np.median(f)) if len(f) >= 3 else None


def t_gender(jid, fid, cues):
    if not FFMPEG or not HAS_NUMPY: raise RuntimeError("needs ffmpeg + numpy (pip install numpy)")
    src = FILES[fid]; roles = []
    for i, c in enumerate(cues):
        f0 = f0_of(src, float(c["start"]), float(c["end"]))
        roles.append("" if f0 is None else "male" if f0 < 165 else "female" if f0 < 255 else "girl")
        JOBS[jid]["progress"] = (i + 1) / max(1, len(cues))
    return {"roles": roles}


def t_align(jid, fid, cues):
    """Re-time each cue to when the voice is really heard in the original audio (mouth open -> mouth closed)."""
    import numpy as np
    if not FFMPEG or not HAS_NUMPY: raise RuntimeError("needs ffmpeg + numpy")
    src = FILES[fid]; out = []; prev_end = 0.0
    for i, c in enumerate(cues):
        a, b = float(c["start"]), float(c["end"]); ns, ne = a, b
        pa = max(0.0, a - 0.5)
        r = subprocess.run([FFMPEG, "-v", "error", "-ss", f"{pa:.3f}", "-t", f"{b - pa + 0.5:.3f}", "-i", src, "-vn", "-ar", "16000",
                            "-ac", "1", "-af", "highpass=f=120,lowpass=f=3800", "-f", "s16le", "-"], capture_output=True)
        x = np.frombuffer(r.stdout, dtype=np.int16).astype(np.float32)
        n = len(x) // 160
        if n >= 20:
            e = np.sqrt((x[:n * 160].reshape(n, 160) ** 2).mean(1))                  # 10 ms energy frames
            thr = max(np.percentile(e, 15) * 2.5, np.percentile(e, 95) * 0.18, 120)
            act = np.convolve((e > thr).astype(np.float32), np.ones(6, np.float32), "same") >= 5
            fa, fb = int((a - pa) * 100), int((b - pa) * 100)
            pre, post = act[max(0, fa - 50):fa], act[fb:fb + 50]
            if not (pre.size and pre.mean() > 0.6):                                   # steady noise/music before = can't trust
                w = np.flatnonzero(act[max(0, fa - 50):fa + 60])
                if len(w): ns = pa + (max(0, fa - 50) + w[0]) / 100
            if not (post.size and post.mean() > 0.6):
                w = np.flatnonzero(act[max(0, fb - 60):fb + 50])
                if len(w): ne = pa + (max(0, fb - 60) + w[-1] + 1) / 100
        ns = max(ns, prev_end + 0.02)
        if ne < ns + 0.3: ns, ne = a, b
        out.append([round(ns, 3), round(ne, 3)]); prev_end = ne
        JOBS[jid]["progress"] = (i + 1) / max(1, len(cues))
        JOBS[jid]["msg"] = f"Aligned line {i + 1}/{len(cues)}: {a:.2f}s → {ns:.2f}s"
    return {"times": out}


def t_dub(jid, fid, cues, engine, voice, rate, bg, maxspeed, strict=True, delay=0.0):
    import wave, numpy as np
    if not FFMPEG: raise RuntimeError("ffmpeg not found")
    if not HAS_NUMPY: raise RuntimeError("numpy missing: pip install numpy")
    src = FILES[fid]
    total = duration(src) or (max(c["end"] for c in cues) + 2)
    cues = sorted([c for c in cues if str(c.get("text", "")).strip()], key=lambda c: c["start"])
    if not cues: raise RuntimeError("No subtitle text to dub")
    tmp = os.path.join(WORK, "dub_" + jid); os.makedirs(tmp, exist_ok=True)
    items = []
    for c in cues:
        v, r, p = line_params(c, voice, rate)
        items.append((re.sub(r"\s+", " ", c["text"]).strip(), v, r, p))
    JOBS[jid]["msg"] = f"Generating {len(items)} character voices (cached lines are reused)…"
    paths = tts_make(jid, engine, items)
    skipped = {k for k, pp in enumerate(paths) if not pp}
    if len(skipped) == len(cues): raise RuntimeError("No line could be spoken. Check internet, run: pip install -U edge-tts")
    JOBS[jid]["msg"] = f"Fitting each line to the character's mouth… ({len(skipped)} lines skipped)" if skipped else "Fitting each line to the character's mouth…"

    buf = np.zeros(int((total + 10) * SR), dtype=np.int32)
    last_e, long_at = 0, []
    for k, c in enumerate(cues):
        if k in skipped: continue
        a = decode(paths[k]); dur = len(a) / SR
        nxt = cues[k + 1]["start"] if k + 1 < len(cues) else total
        slot = max(0.4, c["end"] - c["start"])                # time the character's mouth is moving
        limit = max(slot, min(nxt - c["start"], slot * 1.3))  # a little slack, never drift later lines
        if dur > limit:
            a = decode(paths[k], min(dur / limit, maxspeed))
            if len(a) / SR > limit + 0.3: long_at.append(round(c["start"], 1))
        cap = int((limit + 0.3) * SR)
        if strict and len(a) > cap:                          # the character stopped talking -> stop the voice too
            a = a[:cap].copy(); n = min(len(a), int(0.06 * SR)); a[-n:] = (a[-n:] * np.linspace(1, 0, n)).astype(np.int16)
        s = max(0, int((c["start"] + delay) * SR)); e = s + len(a)              # always start exactly on the cue
        if e > len(buf): buf = np.concatenate([buf, np.zeros(e - len(buf) + SR, dtype=np.int32)])
        buf[s:e] += a; last_e = max(last_e, e)
        JOBS[jid]["progress"] = 0.65 + 0.25 * (k + 1) / len(cues)
    buf = np.clip(buf[: int(max(total, last_e / SR) * SR) + 1], -32768, 32767).astype(np.int16)

    wav = os.path.join(tmp, "dub.wav")
    with wave.open(wav, "wb") as f:
        f.setnchannels(1); f.setsampwidth(2); f.setframerate(SR); f.writeframes(buf.tobytes())
    mp3, mp3url = outfile(".mp3"); mp4, mp4url = outfile(".mp4")
    JOBS[jid]["msg"] = "Mixing the new voice into the video…"
    aid = uuid.uuid4().hex[:8]; keep, _ = outfile(".wav"); shutil.copyfile(wav, keep); FILES[aid] = keep   # lossless voice track for the final export
    ff(["-i", wav, "-b:a", "192k", mp3])
    if bg > 0 and has_audio(src):
        fc = f"[0:a]volume={bg:.2f}[a0];[a0][1:a]amix=inputs=2:duration=longest:dropout_transition=0,volume=2[a]"
        ff(["-i", src, "-i", wav, "-filter_complex", fc, "-map", "0:v?", "-map", "[a]", "-c:v", "copy",
            "-c:a", "aac", "-b:a", "192k", "-t", f"{total:.3f}", mp4], jid, total)
    else:
        ff(["-i", src, "-i", wav, "-map", "0:v?", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
            "-t", f"{total:.3f}", mp4], jid, total)
    shutil.rmtree(tmp, ignore_errors=True)
    return {"url": mp4url, "mp3": mp3url, "aid": aid, "long": long_at, "skipped": len(skipped), "lines": len(cues)}


# ---------------------------------------------------------------- http
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _json(self, o, code=200):
        b = json.dumps(o).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

    def _body(self):
        return json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")

    def do_GET(self):
        u = urlparse(self.path)
        if u.path in ("/", "/index.html"):
            b = open(os.path.join(HERE, "index.html"), "rb").read()
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
        elif u.path == "/api/status":
            self._json({"ffmpeg": bool(FFMPEG), "whisper": whisper_kind(), "translate": "nllb" if HAS_NLLB else ("argos" if HAS_ARGOS else None),
                        "cache_mb": folder_mb(WORK), "tts_edge": HAS_EDGE, "tts_mms": HAS_MMS,
                        "sensevoice": importlib.util.find_spec("funasr") is not None,
                        "encoder": (_VENC[1] if _VENC else "…"), "license": LIC.status()})
        elif u.path.startswith("/api/job/"):
            self._json(JOBS.get(u.path.split("/")[-1], {"status": "error", "error": "unknown job"}))
        elif u.path.startswith("/api/tts/"):
            n = os.path.basename(u.path); p = os.path.join(TTS, n)
            if not os.path.isfile(p): return self._json({"error": "not found"}, 404)
            data = open(p, "rb").read()
            self.send_response(200); self.send_header("Content-Type", "audio/mpeg" if p.endswith(".mp3") else "audio/wav")
            self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
        elif u.path.startswith("/api/result/"):
            n = os.path.basename(u.path); p = os.path.join(OUT, n)
            if not os.path.isfile(p): return self._json({"error": "not found"}, 404)
            size = os.path.getsize(p); a, z, code = 0, size - 1, 200
            m = re.match(r"bytes=(\d*)-(\d*)$", self.headers.get("Range", ""))      # lets <video> seek without downloading everything
            if m and (m.group(1) or m.group(2)):
                if m.group(1): a = int(m.group(1)); z = min(size - 1, int(m.group(2))) if m.group(2) else size - 1
                else: a = max(0, size - int(m.group(2)))
                if a > z:
                    self.send_response(416); self.send_header("Content-Range", f"bytes */{size}"); self.end_headers(); return
                code = 206
            self.send_response(code); self.send_header("Content-Type", "audio/mpeg" if p.endswith(".mp3") else "video/mp4")
            self.send_header("Accept-Ranges", "bytes"); self.send_header("Content-Length", str(z - a + 1))
            if code == 206: self.send_header("Content-Range", f"bytes {a}-{z}/{size}")
            self.end_headers()
            try:
                with open(p, "rb") as f:
                    f.seek(a); left = z - a + 1
                    while left > 0:
                        c = f.read(min(1 << 20, left))
                        if not c: break
                        self.wfile.write(c); left -= len(c)
            except (BrokenPipeError, ConnectionResetError):
                pass
        else:
            self._json({"error": "not found"}, 404)

    def do_POST(self):
        u = urlparse(self.path)
        try:
            if u.path == "/api/license":
                try: return self._json(LIC.activate(self._body().get("key", "")))
                except ValueError as e: return self._json({"error": str(e)}, 400)
            if u.path != "/api/clear" and not LIC.ok():
                return self._json({"error": "License expired / មិនទាន់មាន License ឬផុតកំណត់ — សូមបញ្ចូលគ្រាប់ចុចថ្មី"}, 402)
            if u.path == "/api/upload":
                name = re.sub(r"[^\w.\-]", "_", parse_qs(u.query).get("name", ["file"])[0])
                fid = uuid.uuid4().hex[:8]; p = os.path.join(UP, fid + "_" + name)
                n = int(self.headers.get("Content-Length", 0))
                with open(p, "wb") as f:
                    while n > 0:
                        c = self.rfile.read(min(1 << 20, n))
                        if not c: break
                        f.write(c); n -= len(c)
                FILES[fid] = p
                return self._json({"id": fid})
            if u.path == "/api/clear":
                for d in (UP, OUT, TTS):
                    shutil.rmtree(d, ignore_errors=True); os.makedirs(d, exist_ok=True)
                FILES.clear()
                return self._json({"ok": True})
            b = self._body()
            if u.path == "/api/sample":
                eng = b.get("engine", "edge"); ext = ".mp3" if eng == "edge" else ".wav"
                p = os.path.join(WORK, "sample_" + uuid.uuid4().hex[:6] + ext)
                v, dp, dr = ROLES.get(b.get("role", ""), (b.get("voice", "km-KH-SreymomNeural"), 0, 0))
                synth(None, eng, [b.get("text", "សួស្តី")[:200]], [p], v, f"{int(b.get('rate', 0)) + dr:+d}%", f"{dp:+d}Hz")
                data = open(p, "rb").read(); os.remove(p)
                self.send_response(200); self.send_header("Content-Type", "audio/mpeg" if ext == ".mp3" else "audio/wav")
                self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data); return
            if u.path == "/api/tts":                        # one line: speak (cached) + real length in seconds
                eng = b.get("engine", "edge")
                v, r, p = line_params(b, b.get("voice", "km-KH-SreymomNeural"), b.get("rate", 0))
                pth = tts_make(None, eng, [(str(b.get("text", ""))[:500], v, r, p)])[0]
                if not pth: return self._json({"error": "Could not speak this line (empty text, or Edge TTS refused: pip install -U edge-tts)"}, 500)
                return self._json({"url": "/api/tts/" + os.path.basename(pth), "dur": round(len(decode(pth)) / SR, 3)})
            if u.path == "/api/audio":                      # 16 kHz mp3 slice, used by "Gemini Listen"
                r = subprocess.run([FFMPEG, "-v", "error", "-ss", f"{float(b['start']):.3f}", "-t", f"{float(b['dur']):.3f}", "-i", FILES[b["id"]],
                                    "-vn", "-ar", "16000", "-ac", "1", "-b:a", "48k", "-f", "mp3", "-"], capture_output=True)
                if r.returncode or not r.stdout: return self._json({"error": (r.stderr.decode(errors="ignore")[-300:] or "ffmpeg failed")}, 500)
                self.send_response(200); self.send_header("Content-Type", "audio/mpeg")
                self.send_header("Content-Length", str(len(r.stdout))); self.end_headers(); self.wfile.write(r.stdout); return
            tasks = {
                "/api/transcribe": lambda: new_job(t_transcribe, b["id"], b.get("lang"), b.get("engine", "whisper")),
                "/api/translate": lambda: new_job(t_translate_free if b.get("mode") == "free" else t_translate, b["texts"], b.get("from", "auto"), b["to"]),
                "/api/removevocal": lambda: new_job(t_removevocal, b["id"]),
                "/api/cut": lambda: new_job(t_cut, b["id"], float(b["start"]), float(b["end"])),
                "/api/merge": lambda: new_job(t_merge, b["ids"]),
                "/api/dub": lambda: new_job(t_dub, b["id"], b["cues"], b.get("engine", "edge"),
                                            b.get("voice", "km-KH-SreymomNeural"), int(b.get("rate", 0)),
                                            float(b.get("bg", 0.1)), float(b.get("maxspeed", 1.35)), bool(b.get("strict", True)), float(b.get("delay", 0.12))),
                "/api/ttsbatch": lambda: new_job(t_ttsbatch, b["cues"], b.get("engine", "edge"), b.get("voice", "km-KH-SreymomNeural"), int(b.get("rate", 0))),
                "/api/align": lambda: new_job(t_align, b["id"], b["cues"]),
                "/api/gender": lambda: new_job(t_gender, b["id"], b["cues"]),
                "/api/removesub": lambda: new_job(t_removesub, b["id"], float(b["x"]), float(b["y"]), float(b["w"]), float(b["h"]), b.get("mode", "blur")),
                "/api/export": lambda: new_job(t_export, b["id"], b.get("aid"), float(b.get("bg", 0.1)), b.get("fx") or {}),
                "/api/burn": lambda: new_job(t_burn, b["id"], b["srt"], b.get("size", 34), b.get("color", "#ffffff"), b.get("bottom", 8)),
            }
            if u.path in tasks: return self._json({"job": tasks[u.path]()})
            self._json({"error": "not found"}, 404)
        except Exception as e:
            self._json({"error": str(e)}, 500)


def open_page(url):
    """Desktop: default browser. Termux: termux-open-url (falls back to printing the address to open by hand)."""
    if os.environ.get("KS_NO_OPEN"): return
    try:
        if IS_TERMUX and shutil.which("termux-open-url"): subprocess.Popen(["termux-open-url", url])
        elif not IS_TERMUX: webbrowser.open(url)
    except Exception:
        pass


def main():
    url = f"http://127.0.0.1:{PORT}"
    import socket
    try:                                                # already running? (double-click twice) -> just open the page
        socket.create_connection(("127.0.0.1", PORT), timeout=0.6).close()
        print("Khmer Studio is already running -> opening", url)
        open_page(url)
        return
    except OSError:
        pass
    srv = ThreadingHTTPServer((HOST, PORT), H)   # localhost only: nothing is exposed to the network
    print(f"  tts    : edge-tts={'yes' if HAS_EDGE else 'no'}  mms={'yes' if HAS_MMS else 'no'}")
    print(f"Khmer Studio → {url}\n  ffmpeg : {FFMPEG or 'NOT FOUND'}\n  whisper: {whisper_kind() or 'not installed'}\n  translate: {'nllb' if HAS_NLLB else ('argos' if HAS_ARGOS else 'not installed')}")
    print("  model  :", WHISPER_CPP_MODEL or WHISPER_MODEL)
    threading.Thread(target=lambda: print("  encoder :", venc()[1], "(GPU)" if venc()[1] != "libx264" else "(CPU)"), daemon=True).start()
    open_page(url)
    try: srv.serve_forever()
    except KeyboardInterrupt: pass

if __name__ == "__main__":
    main()
