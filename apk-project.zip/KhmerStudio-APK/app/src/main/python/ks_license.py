"""Khmer Studio licence: offline, signed keys (Ed25519, pure Python - no packages needed).

A key = base32( "K1" + device(6 bytes, zeros = any phone) + days(uint16) + nonce(4) + signature(64) ).
The app only holds the PUBLIC key (license_pub.txt); the private seed stays with the seller (keygen.py)."""
import base64, hashlib, json, os, struct, time

# ---------------- Ed25519 (RFC 8032, reference implementation) ----------------
_p = 2 ** 255 - 19
_q = 2 ** 252 + 27742317777372353535851937790883648493
_d = -121665 * pow(121666, _p - 2, _p) % _p
_I = pow(2, (_p - 1) // 4, _p)


def _H(m): return hashlib.sha512(m).digest()
def _inv(x): return pow(x, _p - 2, _p)


def _xrec(y):
    xx = (y * y - 1) * _inv(_d * y * y + 1)
    x = pow(xx, (_p + 3) // 8, _p)
    if (x * x - xx) % _p: x = x * _I % _p
    return _p - x if x & 1 else x


_By = 4 * _inv(5) % _p
_B = (_xrec(_By), _By, 1, _xrec(_By) * _By % _p)
_Z = (0, 1, 1, 0)


def _add(P, Q):
    A = (P[1] - P[0]) * (Q[1] - Q[0]) % _p; B = (P[1] + P[0]) * (Q[1] + Q[0]) % _p
    C = 2 * P[3] * Q[3] * _d % _p; D = 2 * P[2] * Q[2] % _p
    E, F, G, Hh = B - A, D - C, D + C, B + A
    return (E * F % _p, G * Hh % _p, F * G % _p, E * Hh % _p)


def _mul(s, P):
    Q = _Z
    while s:
        if s & 1: Q = _add(Q, P)
        P = _add(P, P); s >>= 1
    return Q


def _enc(P):
    zi = _inv(P[2]); x, y = P[0] * zi % _p, P[1] * zi % _p
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _dec(s):
    y = int.from_bytes(s, "little"); sign = y >> 255; y &= (1 << 255) - 1
    x = _xrec(y)
    if x & 1 != sign: x = _p - x
    P = (x, y, 1, x * y % _p)
    if (-P[0] * P[0] + P[1] * P[1] - 1 - _d * P[0] * P[0] * P[1] * P[1]) % _p: raise ValueError("bad point")
    return P


def _clamp(h):
    a = int.from_bytes(h[:32], "little"); a &= (1 << 254) - 8; return a | (1 << 254)


def public_key(seed): return _enc(_mul(_clamp(_H(seed)), _B))


def sign(seed, m):
    h = _H(seed); a = _clamp(h); A = _enc(_mul(a, _B))
    r = int.from_bytes(_H(h[32:] + m), "little") % _q; R = _enc(_mul(r, _B))
    k = int.from_bytes(_H(R + A + m), "little") % _q
    return R + int.to_bytes((r + k * a) % _q, 32, "little")


def verify(pub, m, sig):
    try:
        if len(sig) != 64 or len(pub) != 32: return False
        A, R = _dec(pub), _dec(sig[:32]); S = int.from_bytes(sig[32:], "little")
        if S >= _q: return False
        k = int.from_bytes(_H(sig[:32] + pub + m), "little") % _q
        a, b = _mul(S, _B), _add(R, _mul(k, A))
        return (a[0] * b[2] - b[0] * a[2]) % _p == 0 and (a[1] * b[2] - b[1] * a[2]) % _p == 0
    except Exception:
        return False


# ---------------- keys ----------------
DAY = 86400
b32 = lambda b: base64.b32encode(b).decode().rstrip("=")
unb32 = lambda s: base64.b32decode(s + "=" * (-len(s) % 8))


def clean(k): return "".join(ch for ch in k.upper() if ch.isalnum())


def make_key(seed, days, device="0" * 10):
    dev = unb32(clean(device)) if clean(device).strip("0") else b"\0" * 6
    body = b"K1" + dev[:6].ljust(6, b"\0") + struct.pack(">H", days) + os.urandom(4)
    k = b32(body + sign(seed, body))
    return "-".join(k[i:i + 5] for i in range(0, len(k), 5))


def parse_key(pub, key):
    """-> (days, device_bytes) or raises ValueError"""
    try: raw = unb32(clean(key))
    except Exception: raise ValueError("គ្រាប់ចុចមិនត្រឹមត្រូវ (Invalid key)")
    if len(raw) != 78 or raw[:2] != b"K1" or not verify(pub, raw[:14], raw[14:]):
        raise ValueError("គ្រាប់ចុចមិនត្រឹមត្រូវ (Invalid key)")
    return struct.unpack(">H", raw[8:10])[0], raw[2:8]


class License:
    def __init__(self, app_dir, data_dir):
        self.f = os.path.join(data_dir, "license.json"); self.dev_f = os.path.join(data_dir, "device.id")
        pf = os.path.join(app_dir, "license_pub.txt")
        self.pub = bytes.fromhex(open(pf).read().strip()) if os.path.isfile(pf) else None
        self.required = self.pub is not None
        if not os.path.isfile(self.dev_f):
            open(self.dev_f, "w").write(b32(os.urandom(6)))
        self.device = open(self.dev_f).read().strip()
        self.st = {"expires": 0, "used": [], "last_seen": 0}
        try: self.st.update(json.load(open(self.f)))
        except Exception: pass

    def _save(self):
        try: json.dump(self.st, open(self.f, "w"))
        except OSError: pass

    def now(self):
        t = time.time()
        if t < self.st["last_seen"] - 3600: t = self.st["last_seen"]          # clock set back -> ignore
        if t - self.st["last_seen"] > 60: self.st["last_seen"] = t; self._save()
        return t

    def status(self):
        if not self.required: return {"required": False, "valid": True, "device": self.device}
        left = self.st["expires"] - self.now()
        return {"required": True, "valid": left > 0, "days_left": max(0, int(left // DAY + (1 if left % DAY else 0))) if left > 0 else 0, "device": self.device}

    def ok(self): return (not self.required) or self.status()["valid"]

    def activate(self, key):
        if not self.required: return self.status()
        days, dev = parse_key(self.pub, key)
        if dev != b"\0" * 6 and b32(dev) != self.device:
            raise ValueError("គ្រាប់ចុចនេះសម្រាប់ទូរស័ព្ទផ្សេង (Key is for another phone)")
        h = hashlib.sha256(clean(key).encode()).hexdigest()[:16]
        if h in self.st["used"]: raise ValueError("គ្រាប់ចុចនេះបានប្រើរួចហើយ (Key already used)")
        t = self.now()
        self.st["expires"] = max(self.st["expires"], t) + days * DAY      # renewing adds time on top
        self.st["used"].append(h); self._save()
        return self.status()
